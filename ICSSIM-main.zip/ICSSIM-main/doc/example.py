def multiply(a: float, b: float) -> float:
    """
    Multiply two numbers.

    :param a: First number.
    :param b: Second number.
    :return: The product of a and b.
    """
    return a * b

def print_all():
    """
    it print every thing

    :return: The product of a and b.
    """
    
    print ("Hi")
    return "Hi"


print_all()